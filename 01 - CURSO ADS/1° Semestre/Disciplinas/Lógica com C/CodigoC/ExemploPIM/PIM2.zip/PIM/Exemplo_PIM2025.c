#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_NOME 100
#define MAX_RG 20
#define MAX_CPF 20
#define MAX_RUA 100
#define MAX_NUMERO 10
#define MAX_BAIRRO 50
#define MAX_CIDADE 50

// Subestrutura para uma disciplina com 2 notas bimestrais
typedef struct {
    float bim1;
    float bim2;
} Disciplina;

// Estrutura principal do aluno
typedef struct {
    char nome[MAX_NOME];
    char rg[MAX_RG];
    char cpf[MAX_CPF];
    char rua[MAX_RUA];
    char numero[MAX_NUMERO];
    char bairro[MAX_BAIRRO];
    char cidade[MAX_CIDADE];
    Disciplina lingEstC;   // Linguagem Estruturada em C
    Disciplina python;     // Python
    Disciplina engSoft;    // Engenharia de Software
} Aluno;

// Fun��o para remover '\n' de strings lidas com fgets
void limpar_string(char *str) {
    str[strcspn(str, "\n")] = '\0';
}

int main() {
    FILE *arquivo;
    Aluno aluno;

    // Abre o arquivo em modo de append
    arquivo = fopen("alunos_notas.csv", "a");
    if (arquivo == NULL) {
        printf("Erro ao abrir o arquivo!\n");
        return 1;
    }

    // Escreve o cabe�alho se o arquivo estiver vazio
    fseek(arquivo, 0, SEEK_END);
    if (ftell(arquivo) == 0) {
        fprintf(arquivo,
            "Nome,RG,CPF,Rua,Numero,Bairro,Cidade,"
            "LingEstC_Bim1,LingEstC_Bim2,"
            "Python_Bim1,Python_Bim2,"
            "EngSoft_Bim1,EngSoft_Bim2\n"
        );
    }

    // --- Dados pessoais ---
    printf("=== Dados do Aluno ===\n");
    printf("Nome: ");
    fgets(aluno.nome, sizeof(aluno.nome), stdin);
    limpar_string(aluno.nome);

    printf("RG: ");
    fgets(aluno.rg, sizeof(aluno.rg), stdin);
    limpar_string(aluno.rg);

    printf("CPF: ");
    fgets(aluno.cpf, sizeof(aluno.cpf), stdin);
    limpar_string(aluno.cpf);

    printf("Rua: ");
    fgets(aluno.rua, sizeof(aluno.rua), stdin);
    limpar_string(aluno.rua);

    printf("Numero: ");
    fgets(aluno.numero, sizeof(aluno.numero), stdin);
    limpar_string(aluno.numero);

    printf("Bairro: ");
    fgets(aluno.bairro, sizeof(aluno.bairro), stdin);
    limpar_string(aluno.bairro);

    printf("Cidade: ");
    fgets(aluno.cidade, sizeof(aluno.cidade), stdin);
    limpar_string(aluno.cidade);

    // --- Notas: Linguagem Estruturada em C ---
    printf("\n=== Notas - Linguagem Estruturada em C ===\n");
    printf("Nota Bimestre 1: ");
    scanf("%f", &aluno.lingEstC.bim1);
    printf("Nota Bimestre 2: ");
    scanf("%f", &aluno.lingEstC.bim2);

    // --- Notas: Python ---
    printf("\n=== Notas - Python ===\n");
    printf("Nota Bimestre 1: ");
    scanf("%f", &aluno.python.bim1);
    printf("Nota Bimestre 2: ");
    scanf("%f", &aluno.python.bim2);

    // --- Notas: Engenharia de Software ---
    printf("\n=== Notas - Engenharia de Software ===\n");
    printf("Nota Bimestre 1: ");
    scanf("%f", &aluno.engSoft.bim1);
    printf("Nota Bimestre 2: ");
    scanf("%f", &aluno.engSoft.bim2);

    // Consome o '\n' restante no buffer ap�s o �ltimo scanf
    getchar();

    // Escreve todos os dados no CSV (com aspas para seguran�a)
    fprintf(arquivo,
        "\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\","
        "%.2f,%.2f,"
        "%.2f,%.2f,"
        "%.2f,%.2f\n",
        aluno.nome,
        aluno.rg,
        aluno.cpf,
        aluno.rua,
        aluno.numero,
        aluno.bairro,
        aluno.cidade,
        aluno.lingEstC.bim1, aluno.lingEstC.bim2,
        aluno.python.bim1, aluno.python.bim2,
        aluno.engSoft.bim1, aluno.engSoft.bim2
    );

    fclose(arquivo);
    printf("\n Dados do aluno e notas salvos com sucesso em 'alunos_notas.csv'!\n");

    return 0;
}
