import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from PIL import Image, ImageTk
import csv
import os
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

# Variável global para armazenar os dados do CSV
dados_alunos = []
caminho_arquivo_atual = None

def selecionar_arquivo():
    global caminho_arquivo_atual, dados_alunos
    caminho = filedialog.askopenfilename(
        title="Selecione o arquivo CSV de alunos",
        filetypes=[("Arquivos CSV", "*.csv"), ("Todos os arquivos", "*.*")]
    )
    if not caminho:
        return

    caminho_arquivo_atual = caminho
    dados_alunos.clear()

    try:
        with open(caminho, mode="r", encoding="utf-8") as f:
            leitor = csv.reader(f)
            linhas = list(leitor)
            if not linhas:
                messagebox.showwarning("Aviso", "Arquivo vazio.")
                return
            cabecalho = linhas[0]
            # Verifica se tem o número mínimo de colunas (13)
            if len(cabecalho) < 13:
                messagebox.showerror("Erro", "O arquivo CSV não contém todas as colunas esperadas (dados + notas).")
                return
            dados_alunos = linhas[1:]  # Pula o cabeçalho
            messagebox.showinfo("Sucesso", f"Arquivo carregado com {len(dados_alunos)} aluno(s).")
    except Exception as e:
        messagebox.showerror("Erro", f"Erro ao carregar o arquivo:\n{e}")

def mostrar_dados_pessoais():
    if not dados_alunos:
        messagebox.showwarning("Aviso", "Nenhum arquivo carregado. Clique em 'Selecionar Arquivo CSV' primeiro.")
        return

    # Limpa a Treeview
    for item in tree.get_children():
        tree.delete(item)

    # Colunas de dados pessoais (índices 0 a 6)
    colunas_pessoais = ["Nome", "RG", "CPF", "Rua", "Numero", "Bairro", "Cidade"]
    tree["columns"] = colunas_pessoais
    tree["show"] = "headings"

    larguras = {"Nome": 150, "RG": 100, "CPF": 120, "Rua": 180, "Numero": 60, "Bairro": 120, "Cidade": 120}
    for col in colunas_pessoais:
        tree.heading(col, text=col)
        tree.column(col, width=larguras.get(col, 100), anchor=tk.W)

    for linha in dados_alunos:
        if len(linha) >= 7:
            tree.insert("", "end", values=linha[0:7])

def mostrar_notas():
    if not dados_alunos:
        messagebox.showwarning("Aviso", "Nenhum arquivo carregado.")
        return

    for item in tree.get_children():
        tree.delete(item)

    # Colunas de notas (índices 7 a 12)
    colunas_notas = [
        "LingEstC_Bim1", "LingEstC_Bim2",
        "Python_Bim1", "Python_Bim2",
        "EngSoft_Bim1", "EngSoft_Bim2"
    ]
    tree["columns"] = colunas_notas
    tree["show"] = "headings"

    for col in colunas_notas:
        tree.heading(col, text=col)
        tree.column(col, width=90, anchor=tk.CENTER)

    for linha in dados_alunos:
        if len(linha) >= 13:
            tree.insert("", "end", values=linha[7:13])

def gerar_grafico():
    if not dados_alunos:
        messagebox.showwarning("Aviso", "Nenhum arquivo carregado.")
        return

    # Usa o primeiro aluno (índice 0) para gerar o gráfico
    aluno = dados_alunos[0]
    if len(aluno) < 13:
        messagebox.showerror("Erro", "Dados insuficientes para gerar gráfico.")
        return

    try:
        # Extrai as notas (converte para float)
        notas = [
            float(aluno[7]), float(aluno[8]),  # Ling.Est.C
            float(aluno[9]), float(aluno[10]), # Python
            float(aluno[11]), float(aluno[12]) # EngSoft
        ]
    except ValueError:
        messagebox.showerror("Erro", "Alguma nota não é um número válido.")
        return

    disciplinas = ["Ling.Est.C", "Python", "EngSoft"]
    bim1 = [notas[0], notas[2], notas[4]]
    bim2 = [notas[1], notas[3], notas[5]]

    # Cria o gráfico
    fig, ax = plt.subplots(figsize=(6, 4))
    largura_barra = 0.35
    indices = range(len(disciplinas))

    barras1 = ax.bar([i - largura_barra/2 for i in indices], bim1, largura_barra, label='Bim 1', color='skyblue')
    barras2 = ax.bar([i + largura_barra/2 for i in indices], bim2, largura_barra, label='Bim 2', color='lightcoral')

    ax.set_xlabel('Disciplinas')
    ax.set_ylabel('Notas')
    ax.set_title(f'Notas de {aluno[0]}')
    ax.set_ylim(0, 10)
    ax.set_xticks(indices)
    ax.set_xticklabels(disciplinas)
    ax.legend()
    ax.grid(axis='y', linestyle='--', alpha=0.7)

    # Adiciona os valores nas barras
    for barra in barras1 + barras2:
        altura = barra.get_height()
        ax.annotate(f'{altura:.1f}',
                    xy=(barra.get_x() + barra.get_width() / 2, altura),
                    xytext=(0, 3),  # 3 pontos acima
                    textcoords="offset points",
                    ha='center', va='bottom')

    # Integra o gráfico na janela Tkinter
    canvas = FigureCanvasTkAgg(fig, master=janela)
    canvas.draw()
    canvas.get_tk_widget().pack(pady=10, padx=10, fill=tk.BOTH, expand=False)

    # Botão para fechar o gráfico
    def fechar_grafico():
        canvas.get_tk_widget().destroy()
        botao_fechar.destroy()

    botao_fechar = tk.Button(janela, text="Fechar Gráfico", command=fechar_grafico, bg="red", fg="white")
    botao_fechar.pack(pady=5)

# --- Configuração da janela principal ---
janela = tk.Tk()
janela.title("Sistema Acadêmico - UNIP")
janela.geometry("900x700")

# --- Imagem UNIP ---
try:
    if os.path.exists("UNIP.jpg"):
        img = Image.open("UNIP.jpg")
        img = img.resize((250, 100), Image.LANCZOS)
        img_tk = ImageTk.PhotoImage(img)
        lbl_img = tk.Label(janela, image=img_tk)
        lbl_img.image = img_tk
        lbl_img.pack(pady=10)
except Exception as e:
    tk.Label(janela, text="UNIP.jpg não encontrado", fg="red").pack()

# --- Botões ---
frame_botoes = tk.Frame(janela)
frame_botoes.pack(pady=10)

btn_selecionar = tk.Button(frame_botoes, text="Selecionar Arquivo CSV", command=selecionar_arquivo, font=("Arial", 10), bg="#2196F3", fg="white")
btn_selecionar.grid(row=0, column=0, padx=5)

btn_pessoais = tk.Button(frame_botoes, text="Mostrar Dados Pessoais", command=mostrar_dados_pessoais, font=("Arial", 10), bg="#4CAF50", fg="white")
btn_pessoais.grid(row=0, column=1, padx=5)

btn_notas = tk.Button(frame_botoes, text="Mostrar Notas", command=mostrar_notas, font=("Arial", 10), bg="#FF9800", fg="white")
btn_notas.grid(row=0, column=2, padx=5)

btn_grafico = tk.Button(frame_botoes, text="Gerar Gráfico", command=gerar_grafico, font=("Arial", 10), bg="#F44336", fg="white")
btn_grafico.grid(row=0, column=3, padx=5)

# --- Treeview ---
frame_tree = tk.Frame(janela)
frame_tree.pack(padx=15, pady=10, fill=tk.BOTH, expand=True)

tree = ttk.Treeview(frame_tree)
tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

scrollbar = ttk.Scrollbar(frame_tree, orient="vertical", command=tree.yview)
scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
tree.configure(yscrollcommand=scrollbar.set)

# --- Iniciar ---
janela.mainloop()