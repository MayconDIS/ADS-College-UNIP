import tkinter as tk
from tkinter import ttk, filedialog, messagebox, simpledialog
from PIL import Image, ImageTk
import csv
import os
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

# === Variáveis globais ===
dados_alunos = []
caminho_arquivo_atual = None
canvas_grafico = None
botao_fechar_grafico = None

def selecionar_arquivo():
    global caminho_arquivo_atual, dados_alunos
    caminho = filedialog.askopenfilename(
        title="Selecione o arquivo CSV de alunos",
        filetypes=[("Arquivos CSV", "*.csv"), ("Todos os arquivos", "*.*")]
    )
    if not caminho:
        return

    caminho_arquivo_atual = caminho
    dados_alunos.clear()

    # Lê o arquivo como texto puro para depuração
    conteudo_bruto = None
    try:
        with open(caminho, 'r', encoding='utf-8') as f:
            conteudo_bruto = f.read()
    except UnicodeDecodeError:
        try:
            with open(caminho, 'r', encoding='latin1') as f:
                conteudo_bruto = f.read()
        except Exception as e:
            messagebox.showerror("Erro", f"Não foi possível ler o arquivo: {e}")
            return

    # Mostra as primeiras linhas no console para diagnóstico
    print("\n=== CONTEÚDO BRUTO DO ARQUIVO (primeiras 3 linhas) ===")
    linhas_bruto = conteudo_bruto.strip().split('\n')
    for i, linha in enumerate(linhas_bruto[:3]):
        print(f"Linha {i+1}: {repr(linha)}")
    print("===============================================\n")

    # Agora analisa com csv.reader
    import io
    try:
        reader = csv.reader(io.StringIO(conteudo_bruto))
        todas_linhas = list(reader)
    except Exception as e:
        messagebox.showerror("Erro CSV", f"Falha ao analisar CSV: {e}")
        return

    if not todas_linhas:
        messagebox.showwarning("Aviso", "Arquivo vazio.")
        return

    cabecalho = todas_linhas[0]
    print(f"Cabeçalho detectado ({len(cabecalho)} colunas): {cabecalho}")

    dados_validos = []
    for i, linha in enumerate(todas_linhas[1:], start=1):
        if len(linha) >= 13:
            dados_validos.append(linha)
        else:
            print(f"LINHA INVÁLIDA {i}: {len(linha)} colunas -> {linha}")

    if not dados_validos:
        messagebox.showerror("Erro", "Nenhum aluno válido encontrado (menos de 13 colunas por linha).")
        return

    dados_alunos = dados_validos
    mostrar_todos_alunos()
    messagebox.showinfo("Sucesso", f"Carregados {len(dados_alunos)} aluno(s) válidos.")
def mostrar_todos_alunos():
    """Mostra todos os alunos (dados + notas) na Treeview"""
    for item in tree.get_children():
        tree.delete(item)

    colunas = [
        "Nome", "RG", "CPF", "Rua", "Numero", "Bairro", "Cidade",
        "LingEstC_B1", "LingEstC_B2",
        "Python_B1", "Python_B2",
        "EngSoft_B1", "EngSoft_B2"
    ]
    tree["columns"] = colunas
    tree["show"] = "headings"

    larguras = {
        "Nome": 140, "RG": 90, "CPF": 110, "Rua": 160, "Numero": 50,
        "Bairro": 100, "Cidade": 100,
        "LingEstC_B1": 75, "LingEstC_B2": 75,
        "Python_B1": 75, "Python_B2": 75,
        "EngSoft_B1": 75, "EngSoft_B2": 75
    }

    for col in colunas:
        tree.heading(col, text=col)
        tree.column(col, width=larguras.get(col, 80), anchor=tk.CENTER if "B" in col else tk.W)

    # Insere TODOS os alunos
    for i, linha in enumerate(dados_alunos):
        if len(linha) >= 13:
            tree.insert("", "end", values=linha[:13])
        else:
            print(f"Aviso: linha {i+1} incompleta.")

def obter_indice_aluno():
    if not dados_alunos:
        messagebox.showwarning("Aviso", "Nenhum aluno carregado.")
        return None

    try:
        num = simpledialog.askinteger(
            "Selecionar Aluno",
            f"Digite o número do aluno (1 a {len(dados_alunos)}):",
            parent=janela,
            minvalue=1,
            maxvalue=len(dados_alunos)
        )
        if num is None:
            return None
        return num - 1
    except Exception:
        messagebox.showerror("Erro", "Entrada inválida.")
        return None

def mostrar_notas():
    indice = obter_indice_aluno()
    if indice is None:
        return

    aluno = dados_alunos[indice]
    nome = aluno[0]

    janela_notas = tk.Toplevel(janela)
    janela_notas.title(f"Notas de {nome}")
    janela_notas.geometry("500x200")

    texto = f"Aluno: {nome}\n\n"
    texto += f"Linguagem Estruturada em C → B1: {aluno[7]}, B2: {aluno[8]}\n"
    texto += f"Python → B1: {aluno[9]}, B2: {aluno[10]}\n"
    texto += f"Engenharia de Software → B1: {aluno[11]}, B2: {aluno[12]}\n"

    tk.Label(janela_notas, text=texto, font=("Arial", 11), justify=tk.LEFT, padx=20, pady=20).pack()

def gerar_grafico():
    global canvas_grafico, botao_fechar_grafico

    # Fecha gráfico anterior
    if canvas_grafico is not None:
        canvas_grafico.get_tk_widget().destroy()
        canvas_grafico = None
    if botao_fechar_grafico is not None:
        botao_fechar_grafico.destroy()
        botao_fechar_grafico = None

    indice = obter_indice_aluno()
    if indice is None:
        return

    aluno = dados_alunos[indice]
    nome = aluno[0]

    try:
        notas = [
            float(aluno[7]), float(aluno[8]),
            float(aluno[9]), float(aluno[10]),
            float(aluno[11]), float(aluno[12])
        ]
    except (ValueError, IndexError):
        messagebox.showerror("Erro", "Notas inválidas ou dados incompletos.")
        return

    disciplinas = ["Ling.Est.C", "Python", "EngSoft"]
    bim1 = [notas[0], notas[2], notas[4]]
    bim2 = [notas[1], notas[3], notas[5]]

    fig, ax = plt.subplots(figsize=(6, 4))
    largura = 0.35
    x = range(len(disciplinas))

    ax.bar([i - largura/2 for i in x], bim1, largura, label='Bim 1', color='skyblue')
    ax.bar([i + largura/2 for i in x], bim2, largura, label='Bim 2', color='lightcoral')

    ax.set_xlabel('Disciplinas')
    ax.set_ylabel('Notas')
    ax.set_title(f'Notas de {nome}')
    ax.set_ylim(0, 10)
    ax.set_xticks(x)
    ax.set_xticklabels(disciplinas)
    ax.legend()
    ax.grid(axis='y', linestyle='--', alpha=0.7)

    for i in range(len(disciplinas)):
        ax.text(i - largura/2, bim1[i] + 0.1, f'{bim1[i]:.1f}', ha='center', va='bottom')
        ax.text(i + largura/2, bim2[i] + 0.1, f'{bim2[i]:.1f}', ha='center', va='bottom')

    canvas_grafico = FigureCanvasTkAgg(fig, master=janela)
    canvas_grafico.draw()
    canvas_grafico.get_tk_widget().pack(pady=10, padx=10, fill=tk.BOTH, expand=False)

    def fechar():
        global canvas_grafico, botao_fechar_grafico
        if canvas_grafico is not None:
            canvas_grafico.get_tk_widget().destroy()
            canvas_grafico = None
        if botao_fechar_grafico is not None:
            botao_fechar_grafico.destroy()
            botao_fechar_grafico = None

    botao_fechar_grafico = tk.Button(janela, text="Fechar Gráfico", command=fechar, bg="red", fg="white")
    botao_fechar_grafico.pack(pady=5)

# === Interface ===
janela = tk.Tk()
janela.title("Sistema Acadêmico - UNIP")
janela.geometry("1000x750")

# Imagem UNIP
try:
    if os.path.exists("UNIP.jpg"):
        img = Image.open("UNIP.jpg")
        img = img.resize((250, 100), Image.LANCZOS)
        img_tk = ImageTk.PhotoImage(img)
        tk.Label(janela, image=img_tk).pack(pady=5)
except Exception as e:
    tk.Label(janela, text="UNIP.jpg não encontrado", fg="red").pack()

# Botões
frame_botoes = tk.Frame(janela)
frame_botoes.pack(pady=10)

tk.Button(frame_botoes, text="Selecionar Arquivo CSV", command=selecionar_arquivo, bg="#2196F3", fg="white").grid(row=0, column=0, padx=5)
tk.Button(frame_botoes, text="Mostrar Todos os Alunos", command=mostrar_todos_alunos, bg="#03A9F4", fg="white").grid(row=0, column=1, padx=5)
tk.Button(frame_botoes, text="Ver Notas de um Aluno", command=mostrar_notas, bg="#FF9800", fg="white").grid(row=0, column=2, padx=5)
tk.Button(frame_botoes, text="Gerar Gráfico de um Aluno", command=gerar_grafico, bg="#F44336", fg="white").grid(row=0, column=3, padx=5)
# Dentro do frame_botoes, após os outros botões:
tk.Button(frame_botoes, text="Sair", command=janela.destroy, bg="#607D8B", fg="white", font=("Arial", 10)).grid(row=0, column=4, padx=5)

# Treeview
frame_tree = tk.Frame(janela)
frame_tree.pack(padx=10, pady=10, fill=tk.BOTH, expand=True)

tree = ttk.Treeview(frame_tree)
tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

scrollbar = ttk.Scrollbar(frame_tree, orient="vertical", command=tree.yview)
scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
tree.configure(yscrollcommand=scrollbar.set)

janela.mainloop()